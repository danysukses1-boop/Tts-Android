package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.AudioWavUtil
import com.example.util.TextSplitterUtil
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RealVoice", appName)
    }

    @Test
    fun `test pcm to wav header creation`() {
        val dummyPcm = ByteArray(4800) { 0 } // 0.1s at 24kHz 16-bit mono
        val wavBytes = AudioWavUtil.pcmToWav(dummyPcm, sampleRate = 24000)

        // Must have 44 bytes header + PCM length
        assertEquals(44 + 4800, wavBytes.size)

        // Verify RIFF and WAVE magic bytes
        assertEquals('R'.code.toByte(), wavBytes[0])
        assertEquals('I'.code.toByte(), wavBytes[1])
        assertEquals('F'.code.toByte(), wavBytes[2])
        assertEquals('F'.code.toByte(), wavBytes[3])

        assertEquals('W'.code.toByte(), wavBytes[8])
        assertEquals('A'.code.toByte(), wavBytes[9])
        assertEquals('V'.code.toByte(), wavBytes[10])
        assertEquals('E'.code.toByte(), wavBytes[11])

        // Verify data chunk
        assertEquals('d'.code.toByte(), wavBytes[36])
        assertEquals('a'.code.toByte(), wavBytes[37])
        assertEquals('t'.code.toByte(), wavBytes[38])
        assertEquals('a'.code.toByte(), wavBytes[39])
    }

    @Test
    fun `test text splitter respects sentence boundaries`() {
        val text = "Halo, selamat datang di RealVoice Studio. Suara ini sangat natural dan manusiawi! Apakah Anda menyukainya? Tentu saja."
        val chunks = TextSplitterUtil.splitIntoNaturalChunks(text, maxChunkSize = 60)

        assertTrue(chunks.size >= 2)
        // Verify no sentences cut in half
        chunks.forEach { chunk ->
            assertTrue(chunk.isNotBlank())
        }
    }
}
