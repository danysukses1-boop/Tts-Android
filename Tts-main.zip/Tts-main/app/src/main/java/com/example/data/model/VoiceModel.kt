package com.example.data.model

data class VoiceModel(
    val id: String,
    val displayName: String,
    val geminiVoiceName: String,
    val category: String,
    val gender: String, // "Pria" or "Wanita"
    val languageDesc: String,
    val toneTags: List<String>,
    val description: String,
    val previewText: String,
    val recommendedFor: String
)

data class SpeechOptions(
    val style: String = "Natural",
    val speed: Float = 1.0f,
    val pitch: String = "Sedang",
    val emotion: String = "Tenang",
    val voiceDirection: String = "Gunakan suara yang hangat dan natural, artikulasi jelas dalam bahasa Indonesia, intonasi bervariasi dengan jeda yang wajar, tidak terdengar seperti robot."
)

object VoiceLibrary {
    val categories = listOf(
        "Semua",
        "Pria Indonesia",
        "Wanita Indonesia",
        "Dokumenter",
        "Storyteller Horor",
        "Iklan & Promo",
        "Percakapan Santai"
    )

    val styles = listOf(
        "Natural",
        "Storytelling",
        "Narration",
        "Conversational",
        "Advertisement",
        "Dramatic"
    )

    val emotions = listOf(
        "Tenang",
        "Bahagia",
        "Sedih",
        "Tegang",
        "Misterius",
        "Antusias"
    )

    val speedOptions = listOf(
        0.8f to "0.8x (Lambat)",
        1.0f to "1.0x (Normal)",
        1.25f to "1.25x (Cepat)"
    )

    val allVoices: List<VoiceModel> = listOf(
        // Pria Indonesia
        VoiceModel(
            id = "id_m_arga",
            displayName = "Arga",
            geminiVoiceName = "Charon",
            category = "Pria Indonesia",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Dewasa", "Tegas", "Berwibawa", "Narator"),
            description = "Suara pria matang dengan artikulasi mantap dan wibawa tinggi, ideal untuk narasi formal dan company profile.",
            previewText = "Selamat datang di RealVoice Studio AI. Suara ini dirancang untuk narasi profesional dan video korporat.",
            recommendedFor = "Company profile, narasi formal, video edukasi"
        ),
        VoiceModel(
            id = "id_m_bima",
            displayName = "Bima",
            geminiVoiceName = "Orus",
            category = "Pria Indonesia",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Tegas", "Kuat", "Percaya Diri"),
            description = "Suara pria berkarakter tegas dan bertenaga, sangat pas untuk presentasi bisnis dan motivasi.",
            previewText = "Keberhasilan dimulai dari keputusan untuk mencoba. Bersama kami, wujudkan visi masa depan Anda hari ini.",
            recommendedFor = "Motivasi, video produk, presentasi pitch"
        ),
        VoiceModel(
            id = "id_m_dimas",
            displayName = "Dimas",
            geminiVoiceName = "Puck",
            category = "Pria Indonesia",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Hangat", "Ramah", "Energik"),
            description = "Suara pria muda yang hangat, bersahabat, dan memikat pendengar dengan nada ceria.",
            previewText = "Hai semuanya! Selamat bergabung di studio suara AI terbaik. Mari mulai kreasi audio Anda sekarang juga.",
            recommendedFor = "Tutorial YouTube, podcast intro, konten media sosial"
        ),
        VoiceModel(
            id = "id_m_bayu",
            displayName = "Bayu",
            geminiVoiceName = "Achird",
            category = "Pria Indonesia",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Santai", "Akrab", "Kasual"),
            description = "Suara percakapan santai seperti mengobrol dengan sahabat karib, sangat natural untuk podcast.",
            previewText = "Halo teman-teman, santai sejenak yuk. Di episode kali ini kita bakal bahas topik yang super seru.",
            recommendedFor = "Podcast, audiobook santai, review vlog"
        ),

        // Wanita Indonesia
        VoiceModel(
            id = "id_f_siti",
            displayName = "Siti",
            geminiVoiceName = "Aoede",
            category = "Wanita Indonesia",
            gender = "Wanita",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Lembut", "Elegan", "Menenangkan"),
            description = "Suara wanita halus, anggun, dan menenangkan hati, sangat cocok untuk meditasi dan audio relaksasi.",
            previewText = "Tarik napas perlahan, rasakan ketenangan mengalir di dalam diri Anda. Nikmati setiap detik kedamaian ini.",
            recommendedFor = "Meditasi, panduan tidur, puisi, kisah inspiratif"
        ),
        VoiceModel(
            id = "id_f_maya",
            displayName = "Maya",
            geminiVoiceName = "Kore",
            category = "Wanita Indonesia",
            gender = "Wanita",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Dewasa", "Jelas", "Elegan", "Narator"),
            description = "Suara wanita profesional, artikulatif, dan percaya diri, standar emas untuk penyiar berita dan dokumenter.",
            previewText = "Kabar utama hari ini: inovasi kecerdasan buatan terus berkembang pesat dan merevolusi industri media digital.",
            recommendedFor = "Berita, e-learning, dokumenter, audio korporat"
        ),
        VoiceModel(
            id = "id_f_dewi",
            displayName = "Dewi",
            geminiVoiceName = "Zephyr",
            category = "Wanita Indonesia",
            gender = "Wanita",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Ceria", "Antusias", "Segar"),
            description = "Suara wanita riang dan ceria, memberikan suntikan energi positif untuk konten promosi dan anak muda.",
            previewText = "Kabar gembira buat kamu! Dapatkan diskon spesial hingga lima puluh persen khusus untuk hari ini saja!",
            recommendedFor = "Iklan radio, TikTok/Reels, pengumuman event"
        ),
        VoiceModel(
            id = "id_f_putri",
            displayName = "Putri",
            geminiVoiceName = "Schedar",
            category = "Wanita Indonesia",
            gender = "Wanita",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Halus", "Edukatif", "Teratur"),
            description = "Suara wanita dengan intonasi stabil dan artikulasi presisi, terbaik untuk kursus online dan buku audio.",
            previewText = "Pada bab ketiga, kita akan mempelajari prinsip dasar pernapasan dan artikulasi vokal dalam berbicara di depan umum.",
            recommendedFor = "Kursus online, penjelasan instruksi, audio guide"
        ),

        // Dokumenter Profesional
        VoiceModel(
            id = "id_doc_hendra",
            displayName = "Prof. Hendra",
            geminiVoiceName = "Rasalgethi",
            category = "Dokumenter",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Informatif", "Mendalam", "Berwawasan"),
            description = "Vokal dokumenter mendalam dengan pembawaan ilmiah yang memikat rasa ingin tahu pendengar.",
            previewText = "Di kedalaman samudra Hindia, terdapat ekosistem terumbu karang purba yang telah bertahan selama ribuan tahun.",
            recommendedFor = "Dokumenter sains, sejarah, National Geographic style"
        ),

        // Storyteller Horor & Misteri
        VoiceModel(
            id = "id_story_danang",
            displayName = "Ki Danang",
            geminiVoiceName = "Fenrir",
            category = "Storyteller Horor",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Misterius", "Tegang", "Dramatis"),
            description = "Vokal berat penuh misteri dengan jeda teatrikal, membangkitkan suasana horor dan ketegangan mendalam.",
            previewText = "Malam itu, jam dinding berdentang tepat pukul dua belas... Langkah kaki misterius mulai terdengar di lorong sepi.",
            recommendedFor = "Cerita horor, misteri true-crime, sandiwara radio"
        ),

        // Iklan & Promosi
        VoiceModel(
            id = "id_ad_rian",
            displayName = "Rian Komersial",
            geminiVoiceName = "Puck",
            category = "Iklan & Promo",
            gender = "Pria",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Persuasif", "Dinamis", "Cepat"),
            description = "Penyampaian cepat, tegas, dan membujuk untuk kebutuhan iklan promosi komersial modern.",
            previewText = "Jangan sampai kehabisan! Beli sekarang dan nikmati gratis ongkos kirim ke seluruh pelosok Indonesia!",
            recommendedFor = "Iklan komersial, teaser promo, bumper video"
        ),

        // Percakapan Santai
        VoiceModel(
            id = "id_conv_nadia",
            displayName = "Nadia Asisten",
            geminiVoiceName = "Sulafat",
            category = "Percakapan Santai",
            gender = "Wanita",
            languageDesc = "Indonesia & English",
            toneTags = listOf("Hangat", "Sopan", "Membantu"),
            description = "Suara percakapan customer care atau virtual receptionist yang sopan, ramah, dan menenangkan.",
            previewText = "Selamat pagi, terima kasih telah menghubungi kami. Ada yang bisa saya bantu untuk kebutuhan Anda hari ini?",
            recommendedFor = "IVR customer service, virtual receptionist, dialog santai"
        )
    )

    fun getVoiceById(id: String): VoiceModel {
        return allVoices.find { it.id == id } ?: allVoices.first()
    }
}
