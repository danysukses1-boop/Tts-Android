package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppSettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("realvoice_settings", Context.MODE_PRIVATE)

    private val _apiKey = MutableStateFlow(getSavedOrBuildConfigKey())
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _selectedModel = MutableStateFlow(getEffectiveModel())
    val selectedModel: StateFlow<String> = _selectedModel.asStateFlow()

    private val _chunkLongScripts = MutableStateFlow(prefs.getBoolean("chunk_long_scripts", true))
    val chunkLongScripts: StateFlow<Boolean> = _chunkLongScripts.asStateFlow()

    private fun getEffectiveModel(): String {
        val saved = prefs.getString("selected_model", null)
        // Automatically migrate deprecated models (e.g., gemini-2.0-flash or gemini-2.5-flash) to official TTS models
        return if (saved.isNullOrBlank() ||
            saved == "gemini-2.0-flash" ||
            saved == "gemini-2.5-flash" ||
            availableModels.none { it.first == saved }
        ) {
            prefs.edit().putString("selected_model", DEFAULT_MODEL).apply()
            DEFAULT_MODEL
        } else {
            saved
        }
    }

    fun getEffectiveApiKey(): String {
        val customKey = prefs.getString("custom_api_key", "")?.trim().orEmpty()
        if (customKey.isNotBlank()) return customKey
        val buildConfigKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildConfigKey.isNotBlank() && buildConfigKey != "MY_GEMINI_API_KEY") {
            return buildConfigKey
        }
        return ""
    }

    private fun getSavedOrBuildConfigKey(): String {
        return getEffectiveApiKey()
    }

    fun saveCustomApiKey(key: String) {
        val trimmed = key.trim()
        prefs.edit().putString("custom_api_key", trimmed).apply()
        _apiKey.value = getEffectiveApiKey()
    }

    fun setModel(model: String) {
        val validModel = if (availableModels.any { it.first == model }) model else DEFAULT_MODEL
        prefs.edit().putString("selected_model", validModel).apply()
        _selectedModel.value = validModel
    }

    fun setChunkLongScripts(enabled: Boolean) {
        prefs.edit().putBoolean("chunk_long_scripts", enabled).apply()
        _chunkLongScripts.value = enabled
    }

    fun hasValidApiKey(): Boolean {
        return getEffectiveApiKey().isNotBlank()
    }

    fun isUsingBuildConfigKey(): Boolean {
        val customKey = prefs.getString("custom_api_key", "")?.trim().orEmpty()
        return customKey.isEmpty() && BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash-tts"

        val availableModels = listOf(
            "gemini-3.8-flash-tts" to "Gemini 3.8 Flash TTS (Direkomendasikan - Kualitas Studio)",
            "gemini-2.5-flash-preview-tts" to "Gemini 2.5 Flash Preview TTS (Ekspresif)",
            "gemini-3.1-flash-tts-preview" to "Gemini 3.1 Flash TTS Preview (Audio Cerdas)",
            "gemini-3.8-flash-lite-tts" to "Gemini 3.8 Flash Lite TTS (Hemat Kuota)"
        )
    }
}
