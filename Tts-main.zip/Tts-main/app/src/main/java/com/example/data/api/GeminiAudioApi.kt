package com.example.data.api

import android.util.Base64
import android.util.Log
import com.example.util.AudioWavUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

private const val TAG = "GeminiAudioApi"

class GeminiAudioApi(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
) {

    /**
     * Synthesizes audio speech from text using Google Gemini Audio model.
     * Compatible with official TTS models: gemini-3.8-flash-tts, gemini-2.5-flash-preview-tts, etc.
     */
    suspend fun generateSpeech(
        apiKey: String,
        modelName: String = "gemini-3.8-flash-tts",
        text: String,
        geminiVoiceName: String,
        voiceDirection: String = "",
        style: String = "",
        emotion: String = "",
        speed: Float = 1.0f
    ): SpeechResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalArgumentException(
                "API Key Gemini belum disetel. Buka menu Pengaturan untuk memasukkan kunci API atau atur di Secrets panel AI Studio."
            )
        }

        val cleanText = text.trim()
        if (cleanText.isEmpty()) {
            throw IllegalArgumentException("Teks naskah tidak boleh kosong.")
        }

        // Endpoint: https://generativelanguage.googleapis.com/v1beta/models/{modelName}:generateContent?key={apiKey}
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

        // Build Gemini JSON Request Payload strictly compatible with Gemini TTS models
        // NOTE: Gemini TTS models accept raw text in contents and speechConfig with voiceName.
        // systemInstruction is NOT enabled on TTS models and will cause HTTP 400.
        val payload = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                val userTurn = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().apply { put("text", cleanText) })
                    }
                    put("parts", partsArray)
                }
                put(userTurn)
            }
            put("contents", contentsArray)

            // Generation Config with AUDIO modality and speechConfig
            val genConfig = JSONObject().apply {
                put("responseModalities", JSONArray().apply { put("AUDIO") })
                val speechConfig = JSONObject().apply {
                    val voiceConfig = JSONObject().apply {
                        val prebuiltVoiceConfig = JSONObject().apply {
                            put("voiceName", geminiVoiceName)
                        }
                        put("prebuiltVoiceConfig", prebuiltVoiceConfig)
                    }
                    put("voiceConfig", voiceConfig)
                }
                put("speechConfig", speechConfig)
            }
            put("generationConfig", genConfig)
        }

        val requestBody = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .header("Content-Type", "application/json")
            .build()

        try {
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.e(TAG, "API Call Failed: code=${response.code}, body=$responseBody")
                val friendlyError = parseApiError(response.code, responseBody, modelName)
                throw IOException(friendlyError)
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                throw IOException("Model Gemini tidak mengembalikan kandidat suara (respons kosong dari server).")
            }

            val candidate = candidates.getJSONObject(0)
            val content = candidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (parts == null || parts.length() == 0) {
                throw IOException("Tidak ada bagian konten yang diterima dari model.")
            }

            var audioBase64: String? = null
            var mimeType = "audio/wav"

            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val inlineData = part.optJSONObject("inlineData")
                if (inlineData != null) {
                    audioBase64 = inlineData.optString("data")
                    mimeType = inlineData.optString("mimeType", mimeType)
                    break
                }
            }

            if (audioBase64.isNullOrEmpty()) {
                throw IOException("Model menghasilkan teks alih-alih data audio suara. Pastikan model yang dipilih adalah model TTS resmi.")
            }

            val rawAudioBytes = Base64.decode(audioBase64, Base64.DEFAULT)
            if (rawAudioBytes.isEmpty()) {
                throw IOException("Data audio yang diterima kosong (0 byte).")
            }

            // Check if returned data is already a complete RIFF WAVE file
            val isRiffWav = rawAudioBytes.size >= 12 &&
                    rawAudioBytes[0] == 'R'.code.toByte() &&
                    rawAudioBytes[1] == 'I'.code.toByte() &&
                    rawAudioBytes[2] == 'F'.code.toByte() &&
                    rawAudioBytes[3] == 'F'.code.toByte() &&
                    rawAudioBytes[8] == 'W'.code.toByte() &&
                    rawAudioBytes[9] == 'A'.code.toByte() &&
                    rawAudioBytes[10] == 'V'.code.toByte() &&
                    rawAudioBytes[11] == 'E'.code.toByte()

            val sampleRate = extractSampleRate(mimeType)

            val pcmBytes = if (isRiffWav) {
                AudioWavUtil.extractPcmFromWav(rawAudioBytes)
            } else {
                rawAudioBytes
            }

            SpeechResult(
                rawBytes = rawAudioBytes,
                pcmBytes = pcmBytes,
                sampleRate = sampleRate,
                isPrebuiltWav = isRiffWav
            )
        } catch (e: UnknownHostException) {
            Log.e(TAG, "Network connection error", e)
            throw IOException("Tidak dapat terhubung ke server Google (DNS/Koneksi gagal). Periksa koneksi internet Anda.", e)
        } catch (e: SocketTimeoutException) {
            Log.e(TAG, "Socket timeout", e)
            throw IOException("Permintaan sintesis suara melebihi batas waktu (timeout). Silakan coba lagi.", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error generating speech", e)
            throw e
        }
    }

    private fun extractSampleRate(mimeType: String): Int {
        val rateMatch = Regex("rate=(\\d+)").find(mimeType)
        return rateMatch?.groupValues?.get(1)?.toIntOrNull() ?: 24000
    }

    private fun parseApiError(code: Int, body: String, modelName: String): String {
        return try {
            val json = JSONObject(body)
            val error = json.optJSONObject("error")
            val msg = error?.optString("message") ?: ""
            val status = error?.optString("status") ?: ""

            when (code) {
                400 -> {
                    when {
                        msg.contains("API key", ignoreCase = true) ->
                            "Kunci API Gemini tidak valid atau belum diaktifkan. Periksa API Key di menu Pengaturan."
                        msg.contains("Developer instruction", ignoreCase = true) ->
                            "Parameter instruksi tidak didukung pada model TTS ini."
                        msg.contains("voice", ignoreCase = true) ->
                            "Nama karakter suara tidak didukung oleh model: $msg"
                        else ->
                            "Permintaan atau parameter tidak valid (HTTP 400): $msg"
                    }
                }
                401 -> {
                    "Autentikasi gagal (HTTP 401). Kunci API Gemini tidak valid. Masukkan kunci yang benar di Pengaturan."
                }
                403 -> {
                    "Akses ditolak (HTTP 403). Pastikan Gemini API aktif di Google Cloud Console dan akun memiliki kuota."
                }
                404 -> {
                    "Model atau endpoint TTS tidak ditemukan (HTTP 404). Model '$modelName' mungkin sudah usang. Pilih model resmi seperti gemini-3.8-flash-tts di Pengaturan."
                }
                429 -> {
                    val waitMatch = Regex("retry in ([0-9.]+)s", RegexOption.IGNORE_CASE).find(msg)
                    val waitSec = waitMatch?.groupValues?.get(1)
                    if (waitSec != null) {
                        "Batas kuota atau rate limit Gemini API terlampaui (HTTP 429). Tunggu sekitar ${waitSec.toDouble().toInt()} detik lalu coba lagi."
                    } else {
                        "Batas kuota atau rate limit Gemini API terlampaui (HTTP 429). Silakan tunggu beberapa saat atau periksa kuota akun di Google AI Studio."
                    }
                }
                500, 503 -> {
                    "Server Google Gemini sedang sibuk atau mengalami gangguan sementara (HTTP $code). Coba beberapa saat lagi."
                }
                else -> {
                    if (msg.isNotBlank()) "Gagal memproses audio (HTTP $code): $msg"
                    else "Terjadi kesalahan saat memanggil API Gemini (HTTP $code)."
                }
            }
        } catch (_: Exception) {
            when (code) {
                400 -> "Permintaan tidak valid (HTTP 400)."
                401 -> "Autentikasi gagal (HTTP 401)."
                403 -> "Izin akses ditolak (HTTP 403)."
                404 -> "Model tidak ditemukan (HTTP 404). Pilih model resmi seperti gemini-3.8-flash-tts di Pengaturan."
                429 -> "Batas kuota API terlampaui (HTTP 429)."
                else -> "Kesalahan server HTTP $code: $body"
            }
        }
    }
}

data class SpeechResult(
    val rawBytes: ByteArray,
    val pcmBytes: ByteArray,
    val sampleRate: Int,
    val isPrebuiltWav: Boolean
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as SpeechResult
        return rawBytes.contentEquals(other.rawBytes) && sampleRate == other.sampleRate
    }

    override fun hashCode(): Int {
        var result = rawBytes.contentHashCode()
        result = 31 * result + sampleRate
        return result
    }
}
