package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryPurple,
    onPrimary = Color.White,
    primaryContainer = PrimaryPurpleDark,
    onPrimaryContainer = Color(0xFFEDE9FE),
    secondary = SecondaryCyan,
    onSecondary = Color.Black,
    secondaryContainer = SecondaryCyanDark,
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = AccentPink,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = TextSecondary,
    outline = CardBorderDark,
    outlineVariant = Color(0xFF1E1A38),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun RealVoiceTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
