package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AudioHistoryDao {
    @Query("SELECT * FROM audio_history ORDER BY createdAt DESC")
    fun getAllHistory(): Flow<List<AudioHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(audio: AudioHistoryEntity): Long

    @Query("DELETE FROM audio_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM audio_history")
    suspend fun clearAll()
}
