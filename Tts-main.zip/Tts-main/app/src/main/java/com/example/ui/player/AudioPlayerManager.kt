package com.example.ui.player

import android.media.MediaPlayer
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

private const val TAG = "AudioPlayerManager"

data class PlayerState(
    val currentPath: String? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0
)

class AudioPlayerManager(
    private val scope: CoroutineScope
) {
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    fun play(filePath: String) {
        val file = File(filePath)
        if (!file.exists()) {
            Log.e(TAG, "Audio file does not exist: $filePath")
            return
        }

        try {
            if (_playerState.value.currentPath == filePath && mediaPlayer != null) {
                if (!_playerState.value.isPlaying) {
                    mediaPlayer?.start()
                    _playerState.value = _playerState.value.copy(isPlaying = true)
                    startProgressTracking()
                    return
                }
            }

            stopInternal()

            mediaPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                setOnCompletionListener {
                    _playerState.value = _playerState.value.copy(
                        isPlaying = false,
                        currentPositionMs = duration
                    )
                    stopProgressTracking()
                }
                start()
            }

            val dur = mediaPlayer?.duration ?: 0
            _playerState.value = PlayerState(
                currentPath = filePath,
                isPlaying = true,
                currentPositionMs = 0,
                durationMs = dur
            )
            startProgressTracking()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio file $filePath", e)
            stopInternal()
        }
    }

    fun pause() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                    _playerState.value = _playerState.value.copy(
                        isPlaying = false,
                        currentPositionMs = it.currentPosition
                    )
                    stopProgressTracking()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing audio", e)
        }
    }

    fun seekTo(positionMs: Int) {
        try {
            mediaPlayer?.seekTo(positionMs)
            _playerState.value = _playerState.value.copy(currentPositionMs = positionMs)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking audio", e)
        }
    }

    fun stop() {
        stopInternal()
    }

    private fun stopInternal() {
        stopProgressTracking()
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        mediaPlayer = null
        _playerState.value = _playerState.value.copy(isPlaying = false, currentPositionMs = 0)
    }

    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                mediaPlayer?.let { player ->
                    try {
                        if (player.isPlaying) {
                            _playerState.value = _playerState.value.copy(
                                currentPositionMs = player.currentPosition,
                                durationMs = player.duration
                            )
                        }
                    } catch (_: Exception) {}
                }
                delay(150)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stopInternal()
        _playerState.value = PlayerState()
    }
}
