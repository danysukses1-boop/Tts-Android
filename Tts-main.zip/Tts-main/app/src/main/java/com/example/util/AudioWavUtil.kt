package com.example.util

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioWavUtil {

    /**
     * Converts raw 16-bit PCM little-endian audio bytes to standard RIFF/WAVE format.
     */
    fun pcmToWav(
        pcmData: ByteArray,
        sampleRate: Int = 24000,
        channels: Short = 1,
        bitsPerSample: Short = 16
    ): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = (sampleRate * channels * bitsPerSample / 8)
        val blockAlign = (channels * bitsPerSample / 8).toShort()

        val header = ByteArray(44)
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF chunk descriptor
        buffer.put('R'.code.toByte())
        buffer.put('I'.code.toByte())
        buffer.put('F'.code.toByte())
        buffer.put('F'.code.toByte())
        buffer.putInt(totalDataLen)
        buffer.put('W'.code.toByte())
        buffer.put('A'.code.toByte())
        buffer.put('V'.code.toByte())
        buffer.put('E'.code.toByte())

        // "fmt " sub-chunk
        buffer.put('f'.code.toByte())
        buffer.put('m'.code.toByte())
        buffer.put('t'.code.toByte())
        buffer.put(' '.code.toByte())
        buffer.putInt(16) // Subchunk1Size for PCM
        buffer.putShort(1) // AudioFormat 1 = PCM
        buffer.putShort(channels)
        buffer.putInt(sampleRate)
        buffer.putInt(byteRate)
        buffer.putShort(blockAlign)
        buffer.putShort(bitsPerSample)

        // "data" sub-chunk
        buffer.put('d'.code.toByte())
        buffer.put('a'.code.toByte())
        buffer.put('t'.code.toByte())
        buffer.put('a'.code.toByte())
        buffer.putInt(pcmData.size)

        val output = ByteArrayOutputStream(44 + pcmData.size)
        output.write(header)
        output.write(pcmData)
        return output.toByteArray()
    }

    /**
     * Extracts pure PCM data from a RIFF/WAVE file by parsing chunk headers.
     * This safely avoids any metadata chunks (like C2PA provenance) at the end.
     */
    fun extractPcmFromWav(wavBytes: ByteArray): ByteArray {
        if (wavBytes.size < 44) return wavBytes

        // Verify RIFF and WAVE magic numbers
        if (wavBytes[0] == 'R'.code.toByte() &&
            wavBytes[1] == 'I'.code.toByte() &&
            wavBytes[2] == 'F'.code.toByte() &&
            wavBytes[3] == 'F'.code.toByte() &&
            wavBytes[8] == 'W'.code.toByte() &&
            wavBytes[9] == 'A'.code.toByte() &&
            wavBytes[10] == 'V'.code.toByte() &&
            wavBytes[11] == 'E'.code.toByte()
        ) {
            var offset = 12
            while (offset + 8 <= wavBytes.size) {
                val chunkId = String(wavBytes, offset, 4, Charsets.US_ASCII)
                val chunkSize = ByteBuffer.wrap(wavBytes, offset + 4, 4)
                    .order(ByteOrder.LITTLE_ENDIAN).int
                val dataStart = offset + 8

                if (chunkId == "data" && chunkSize > 0) {
                    val dataEnd = (dataStart + chunkSize).coerceAtMost(wavBytes.size)
                    return wavBytes.copyOfRange(dataStart, dataEnd)
                }

                offset = dataStart + chunkSize
            }
            // Fallback: standard 44-byte header
            return wavBytes.copyOfRange(44, wavBytes.size)
        }

        return wavBytes
    }

    /**
     * Writes PCM data as a valid WAV file.
     */
    fun savePcmAsWavFile(
        file: File,
        pcmData: ByteArray,
        sampleRate: Int = 24000
    ) {
        val wavBytes = pcmToWav(pcmData, sampleRate)
        FileOutputStream(file).use { fos ->
            fos.write(wavBytes)
            fos.flush()
        }
    }

    /**
     * Calculates duration in milliseconds for raw 16-bit mono PCM at the given sample rate.
     */
    fun calculateDurationMs(pcmLength: Int, sampleRate: Int = 24000): Long {
        if (pcmLength <= 0 || sampleRate <= 0) return 0L
        val bytesPerSecond = sampleRate * 2 // 16-bit mono = 2 bytes per sample
        return (pcmLength.toLong() * 1000L) / bytesPerSecond
    }

    /**
     * Concatenates multiple PCM byte chunks smoothly.
     */
    fun concatenatePcm(chunks: List<ByteArray>): ByteArray {
        val totalSize = chunks.sumOf { it.size }
        val combined = ByteArray(totalSize)
        var offset = 0
        for (chunk in chunks) {
            System.arraycopy(chunk, 0, combined, offset, chunk.size)
            offset += chunk.size
        }
        return combined
    }
}
