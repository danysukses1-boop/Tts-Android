package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiAudioApi
import com.example.data.db.AppDatabase
import com.example.data.db.AudioHistoryEntity
import com.example.data.model.SpeechOptions
import com.example.data.model.VoiceLibrary
import com.example.data.model.VoiceModel
import com.example.data.repository.AppSettingsRepository
import com.example.data.repository.AudioRepository
import com.example.data.repository.GenerationProgress
import com.example.ui.player.AudioPlayerManager
import com.example.ui.player.PlayerState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val api = GeminiAudioApi()
    val settingsRepository = AppSettingsRepository(application)
    private val audioRepository = AudioRepository(application, api, db.audioHistoryDao(), settingsRepository)

    val playerManager = AudioPlayerManager(viewModelScope)
    val playerState: StateFlow<PlayerState> = playerManager.playerState

    // Navigation Tab (0: Studio, 1: Library, 2: History, 3: Settings)
    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    // Script Input
    private val _scriptText = MutableStateFlow(
        "Selamat datang di RealVoice Studio AI. Platform generasi suara cerdas dengan intonasi alami, ekspresi emosional yang kaya, dan kualitas vokal setara manusia profesional."
    )
    val scriptText: StateFlow<String> = _scriptText.asStateFlow()

    // Selected Voice
    private val _selectedVoice = MutableStateFlow(VoiceLibrary.allVoices.first())
    val selectedVoice: StateFlow<VoiceModel> = _selectedVoice.asStateFlow()

    // Speech Options
    private val _speechOptions = MutableStateFlow(SpeechOptions())
    val speechOptions: StateFlow<SpeechOptions> = _speechOptions.asStateFlow()

    // Generation State
    private val _generationState = MutableStateFlow<GenerationProgress>(GenerationProgress.Idle)
    val generationState: StateFlow<GenerationProgress> = _generationState.asStateFlow()

    // Latest Generated Audio Item
    private val _latestAudio = MutableStateFlow<AudioHistoryEntity?>(null)
    val latestAudio: StateFlow<AudioHistoryEntity?> = _latestAudio.asStateFlow()

    // Voice Library Sample Generation/Playing State
    private val _sampleLoadingVoiceId = MutableStateFlow<String?>(null)
    val sampleLoadingVoiceId: StateFlow<String?> = _sampleLoadingVoiceId.asStateFlow()

    // History Flow
    val historyList: StateFlow<List<AudioHistoryEntity>> = audioRepository.historyFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun selectTab(tab: Int) {
        _selectedTab.value = tab
    }

    fun updateScriptText(text: String) {
        _scriptText.value = text
    }

    fun clearScriptText() {
        _scriptText.value = ""
    }

    fun selectVoice(voice: VoiceModel) {
        _selectedVoice.value = voice
    }

    fun updateSpeechOptions(options: SpeechOptions) {
        _speechOptions.value = options
    }

    fun updateVoiceDirection(prompt: String) {
        _speechOptions.value = _speechOptions.value.copy(voiceDirection = prompt)
    }

    fun updateStyle(style: String) {
        _speechOptions.value = _speechOptions.value.copy(style = style)
    }

    fun updateEmotion(emotion: String) {
        _speechOptions.value = _speechOptions.value.copy(emotion = emotion)
    }

    fun updateSpeed(speed: Float) {
        _speechOptions.value = _speechOptions.value.copy(speed = speed)
    }

    fun updatePitch(pitch: String) {
        _speechOptions.value = _speechOptions.value.copy(pitch = pitch)
    }

    fun generateVoice() {
        if (_generationState.value is GenerationProgress.InProgress) return

        viewModelScope.launch {
            try {
                playerManager.stop()
                val result = audioRepository.generateVoice(
                    text = _scriptText.value,
                    voice = _selectedVoice.value,
                    options = _speechOptions.value
                ) { progress ->
                    _generationState.value = progress
                }
                _latestAudio.value = result
                // Auto play generated audio
                playerManager.play(result.filePath)
            } catch (e: Exception) {
                _generationState.value = GenerationProgress.Error(
                    e.localizedMessage ?: "Terjadi kesalahan saat menghasilkan audio."
                )
            }
        }
    }

    fun playVoiceSample(voice: VoiceModel) {
        if (_sampleLoadingVoiceId.value != null) return

        // If currently playing this sample, pause/stop
        viewModelScope.launch {
            _sampleLoadingVoiceId.value = voice.id
            try {
                val sampleItem = audioRepository.generateVoice(
                    text = voice.previewText,
                    voice = voice,
                    options = SpeechOptions(style = "Natural", speed = 1.0f)
                ) {}
                playerManager.play(sampleItem.filePath)
            } catch (e: Exception) {
                _generationState.value = GenerationProgress.Error(
                    "Gagal memutar sampel: ${e.localizedMessage}"
                )
            } finally {
                _sampleLoadingVoiceId.value = null
            }
        }
    }

    fun playAudio(filePath: String) {
        playerManager.play(filePath)
    }

    fun pauseAudio() {
        playerManager.pause()
    }

    fun seekAudio(positionMs: Int) {
        playerManager.seekTo(positionMs)
    }

    fun deleteHistoryItem(item: AudioHistoryEntity) {
        viewModelScope.launch {
            if (playerState.value.currentPath == item.filePath) {
                playerManager.stop()
            }
            if (_latestAudio.value?.id == item.id) {
                _latestAudio.value = null
            }
            audioRepository.deleteHistoryItem(item)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            playerManager.stop()
            _latestAudio.value = null
            audioRepository.clearAllHistory()
        }
    }

    fun saveApiKey(key: String) {
        settingsRepository.saveCustomApiKey(key)
    }

    fun setModel(model: String) {
        settingsRepository.setModel(model)
    }

    fun setChunking(enabled: Boolean) {
        settingsRepository.setChunkLongScripts(enabled)
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
