package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RealVoice Studio AI Dark Luxury Theme Palette
val BackgroundDark = Color(0xFF090814)
val SurfaceDark = Color(0xFF131126)
val SurfaceVariantDark = Color(0xFF1E1A38)
val CardBorderDark = Color(0xFF2E2954)

val PrimaryPurple = Color(0xFF8B5CF6)
val PrimaryPurpleGlow = Color(0xFFA78BFA)
val PrimaryPurpleDark = Color(0xFF5B21B6)

val SecondaryCyan = Color(0xFF06B6D4)
val SecondaryCyanGlow = Color(0xFF22D3EE)
val SecondaryCyanDark = Color(0xFF0E7490)

val AccentPink = Color(0xFFEC4899)
val AccentAmber = Color(0xFFF59E0B)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
