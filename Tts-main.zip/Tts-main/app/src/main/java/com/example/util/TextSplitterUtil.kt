package com.example.util

object TextSplitterUtil {

    /**
     * Estimates audio duration in seconds based on character count and speech speed.
     * Average reading rate in Indonesian is ~140-160 words/min (~800-900 chars/min), or ~14 chars/sec at 1.0x.
     */
    fun estimateDurationSeconds(text: String, speed: Float = 1.0f): Int {
        val clean = text.trim()
        if (clean.isEmpty()) return 0
        val charsPerSecond = 14.0 * speed.coerceAtLeast(0.5f)
        return (clean.length / charsPerSecond).toInt().coerceAtLeast(1)
    }

    /**
     * Splits long scripts into coherent sentence-based chunks,
     * ensuring sentences are never cut in half.
     */
    fun splitIntoNaturalChunks(text: String, maxChunkSize: Int = 400): List<String> {
        val trimmed = text.trim()
        if (trimmed.length <= maxChunkSize) {
            return listOf(trimmed)
        }

        val chunks = mutableListOf<String>()
        // Split by paragraph first
        val paragraphs = trimmed.split(Regex("\n+"))

        var currentChunk = StringBuilder()

        for (paragraph in paragraphs) {
            val pTrimmed = paragraph.trim()
            if (pTrimmed.isEmpty()) continue

            // Split into sentences using punctuation boundaries
            val sentences = pTrimmed.split(Regex("(?<=[.!?…])\\s+"))

            for (sentence in sentences) {
                val sTrimmed = sentence.trim()
                if (sTrimmed.isEmpty()) continue

                if (currentChunk.isNotEmpty() && currentChunk.length + sTrimmed.length + 1 > maxChunkSize) {
                    chunks.add(currentChunk.toString().trim())
                    currentChunk = StringBuilder()
                }

                if (sTrimmed.length > maxChunkSize) {
                    // Extremely long sentence without punctuation: split on comma or semicolon
                    val subClauses = sTrimmed.split(Regex("(?<=[,;])\\s+"))
                    for (clause in subClauses) {
                        if (currentChunk.isNotEmpty() && currentChunk.length + clause.length + 1 > maxChunkSize) {
                            chunks.add(currentChunk.toString().trim())
                            currentChunk = StringBuilder()
                        }
                        if (clause.length > maxChunkSize) {
                            // Split by words as last resort
                            val words = clause.split(Regex("\\s+"))
                            for (word in words) {
                                if (currentChunk.isNotEmpty() && currentChunk.length + word.length + 1 > maxChunkSize) {
                                    chunks.add(currentChunk.toString().trim())
                                    currentChunk = StringBuilder()
                                }
                                if (currentChunk.isNotEmpty()) currentChunk.append(" ")
                                currentChunk.append(word)
                            }
                        } else {
                            if (currentChunk.isNotEmpty()) currentChunk.append(" ")
                            currentChunk.append(clause)
                        }
                    }
                } else {
                    if (currentChunk.isNotEmpty()) currentChunk.append(" ")
                    currentChunk.append(sTrimmed)
                }
            }
        }

        if (currentChunk.isNotEmpty()) {
            chunks.add(currentChunk.toString().trim())
        }

        return chunks.ifEmpty { listOf(trimmed) }
    }
}
