package com.example.data.repository

import android.content.Context
import com.example.data.api.GeminiAudioApi
import com.example.data.api.SpeechResult
import com.example.data.db.AudioHistoryDao
import com.example.data.db.AudioHistoryEntity
import com.example.data.model.SpeechOptions
import com.example.data.model.VoiceModel
import com.example.util.AudioWavUtil
import com.example.util.TextSplitterUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

sealed class GenerationProgress {
    data object Idle : GenerationProgress()
    data class InProgress(val currentStep: Int, val totalSteps: Int, val message: String) : GenerationProgress()
    data class Success(val historyItem: AudioHistoryEntity) : GenerationProgress()
    data class Error(val message: String) : GenerationProgress()
}

class AudioRepository(
    private val context: Context,
    private val api: GeminiAudioApi,
    private val dao: AudioHistoryDao,
    private val settingsRepository: AppSettingsRepository
) {

    val historyFlow: Flow<List<AudioHistoryEntity>> = dao.getAllHistory()

    private val audioDir: File by lazy {
        val dir = File(context.filesDir, "generated_voices")
        if (!dir.exists()) dir.mkdirs()
        dir
    }

    suspend fun generateVoice(
        text: String,
        voice: VoiceModel,
        options: SpeechOptions,
        onProgress: (GenerationProgress) -> Unit
    ): AudioHistoryEntity = withContext(Dispatchers.IO) {
        val apiKey = settingsRepository.getEffectiveApiKey()
        if (apiKey.isBlank()) {
            val err = "API Key Gemini belum disetel. Buka menu Pengaturan untuk memasukkan kunci API Anda."
            onProgress(GenerationProgress.Error(err))
            throw IllegalArgumentException(err)
        }

        val cleanText = text.trim()
        if (cleanText.isEmpty()) {
            val err = "Teks naskah tidak boleh kosong."
            onProgress(GenerationProgress.Error(err))
            throw IllegalArgumentException(err)
        }

        val modelName = settingsRepository.selectedModel.value
        val shouldChunk = settingsRepository.chunkLongScripts.value

        val chunks = if (shouldChunk && cleanText.length > 400) {
            TextSplitterUtil.splitIntoNaturalChunks(cleanText, maxChunkSize = 400)
        } else {
            listOf(cleanText)
        }

        val totalSteps = chunks.size + 1
        onProgress(GenerationProgress.InProgress(1, totalSteps, "Menghubungi Google Gemini TTS ($modelName)..."))

        val collectedResults = mutableListOf<SpeechResult>()
        val collectedPcm = mutableListOf<ByteArray>()
        var sampleRate = 24000

        for ((index, chunk) in chunks.withIndex()) {
            val stepNumber = index + 1
            val msg = if (chunks.size > 1) {
                "Mensintesis bagian $stepNumber dari ${chunks.size} dengan suara ${voice.displayName}..."
            } else {
                "Mensintesis suara ${voice.displayName} (${voice.geminiVoiceName})..."
            }
            onProgress(GenerationProgress.InProgress(stepNumber, totalSteps, msg))

            try {
                val result = api.generateSpeech(
                    apiKey = apiKey,
                    modelName = modelName,
                    text = chunk,
                    geminiVoiceName = voice.geminiVoiceName,
                    voiceDirection = options.voiceDirection,
                    style = options.style,
                    emotion = options.emotion,
                    speed = options.speed
                )
                collectedResults.add(result)
                collectedPcm.add(result.pcmBytes)
                sampleRate = result.sampleRate
            } catch (e: Exception) {
                val errMsg = e.localizedMessage ?: "Gagal pada bagian $stepNumber"
                onProgress(GenerationProgress.Error(errMsg))
                throw IOException(errMsg, e)
            }
        }

        onProgress(GenerationProgress.InProgress(totalSteps, totalSteps, "Menggabungkan & menyimpan format WAV studio..."))

        val timestamp = System.currentTimeMillis()
        val safeTitle = cleanText.take(35).replace(Regex("[^a-zA-Z0-9\\s]"), "").trim()
            .ifEmpty { "Audio_${voice.displayName}" }
        val fileName = "realvoice_${timestamp}.wav"
        val destFile = File(audioDir, fileName)

        val durationMs: Long

        if (chunks.size == 1 && collectedResults.first().isPrebuiltWav) {
            // Single chunk that returned valid WAV: save directly
            FileOutputStream(destFile).use { fos ->
                fos.write(collectedResults.first().rawBytes)
                fos.flush()
            }
            durationMs = AudioWavUtil.calculateDurationMs(collectedResults.first().pcmBytes.size, sampleRate)
        } else {
            // Multiple chunks or raw PCM: merge PCM and write WAV header
            val mergedPcm = AudioWavUtil.concatenatePcm(collectedPcm)
            AudioWavUtil.savePcmAsWavFile(destFile, mergedPcm, sampleRate)
            durationMs = AudioWavUtil.calculateDurationMs(mergedPcm.size, sampleRate)
        }

        val historyEntity = AudioHistoryEntity(
            title = safeTitle,
            scriptText = cleanText,
            voiceId = voice.id,
            voiceDisplayName = voice.displayName,
            geminiVoiceName = voice.geminiVoiceName,
            style = options.style,
            emotion = options.emotion,
            speed = options.speed,
            durationMs = durationMs,
            charCount = cleanText.length,
            filePath = destFile.absolutePath,
            createdAt = timestamp
        )

        val newId = dao.insert(historyEntity)
        val savedItem = historyEntity.copy(id = newId)

        onProgress(GenerationProgress.Success(savedItem))
        savedItem
    }

    suspend fun deleteHistoryItem(item: AudioHistoryEntity) = withContext(Dispatchers.IO) {
        try {
            val file = File(item.filePath)
            if (file.exists()) file.delete()
        } catch (_: Exception) {}
        dao.deleteById(item.id)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        val files = audioDir.listFiles()
        files?.forEach { it.delete() }
        dao.clearAll()
    }
}
