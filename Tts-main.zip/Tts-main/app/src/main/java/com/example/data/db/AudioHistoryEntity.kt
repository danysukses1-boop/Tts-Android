package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audio_history")
data class AudioHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val scriptText: String,
    val voiceId: String,
    val voiceDisplayName: String,
    val geminiVoiceName: String,
    val style: String,
    val emotion: String,
    val speed: Float,
    val durationMs: Long,
    val charCount: Int,
    val filePath: String,
    val createdAt: Long = System.currentTimeMillis()
)
